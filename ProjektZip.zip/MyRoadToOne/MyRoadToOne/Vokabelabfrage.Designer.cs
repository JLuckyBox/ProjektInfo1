﻿namespace MyRoadToOne
{
    partial class Vokabelabfrage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Vokabelabfrage));
            this.buttonFrenchGer = new System.Windows.Forms.Button();
            this.textBoxAntwort = new System.Windows.Forms.TextBox();
            this.buttonEngFrench = new System.Windows.Forms.Button();
            this.buttonFrenchEng = new System.Windows.Forms.Button();
            this.buttonGerFrench = new System.Windows.Forms.Button();
            this.labelGesSprache = new System.Windows.Forms.Label();
            this.buttonCheck = new System.Windows.Forms.Button();
            this.labelPunkte = new System.Windows.Forms.Label();
            this.buttonBeenden = new System.Windows.Forms.Button();
            this.textBoxGegSprache = new System.Windows.Forms.TextBox();
            this.buttonNeuWort = new System.Windows.Forms.Button();
            this.labelGegSprache = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonFehlerliste = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonFrenchGer
            // 
            resources.ApplyResources(this.buttonFrenchGer, "buttonFrenchGer");
            this.buttonFrenchGer.Name = "buttonFrenchGer";
            this.buttonFrenchGer.UseVisualStyleBackColor = true;
            this.buttonFrenchGer.Click += new System.EventHandler(this.buttonFrenchGer_Click);
            // 
            // textBoxAntwort
            // 
            resources.ApplyResources(this.textBoxAntwort, "textBoxAntwort");
            this.textBoxAntwort.Name = "textBoxAntwort";
            // 
            // buttonEngFrench
            // 
            resources.ApplyResources(this.buttonEngFrench, "buttonEngFrench");
            this.buttonEngFrench.Name = "buttonEngFrench";
            this.buttonEngFrench.UseVisualStyleBackColor = true;
            this.buttonEngFrench.Click += new System.EventHandler(this.buttonEngFrench_Click);
            // 
            // buttonFrenchEng
            // 
            resources.ApplyResources(this.buttonFrenchEng, "buttonFrenchEng");
            this.buttonFrenchEng.Name = "buttonFrenchEng";
            this.buttonFrenchEng.UseVisualStyleBackColor = true;
            this.buttonFrenchEng.Click += new System.EventHandler(this.buttonFrenchEng_Click);
            // 
            // buttonGerFrench
            // 
            resources.ApplyResources(this.buttonGerFrench, "buttonGerFrench");
            this.buttonGerFrench.Name = "buttonGerFrench";
            this.buttonGerFrench.UseVisualStyleBackColor = true;
            this.buttonGerFrench.Click += new System.EventHandler(this.buttonGerFrench_Click);
            // 
            // labelGesSprache
            // 
            resources.ApplyResources(this.labelGesSprache, "labelGesSprache");
            this.labelGesSprache.BackColor = System.Drawing.Color.Transparent;
            this.labelGesSprache.Name = "labelGesSprache";
            this.labelGesSprache.Click += new System.EventHandler(this.labelGesSprache_Click);
            // 
            // buttonCheck
            // 
            this.buttonCheck.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.buttonCheck, "buttonCheck");
            this.buttonCheck.Name = "buttonCheck";
            this.buttonCheck.UseVisualStyleBackColor = false;
            this.buttonCheck.Click += new System.EventHandler(this.buttonCheck_Click);
            // 
            // labelPunkte
            // 
            resources.ApplyResources(this.labelPunkte, "labelPunkte");
            this.labelPunkte.BackColor = System.Drawing.Color.Transparent;
            this.labelPunkte.Name = "labelPunkte";
            // 
            // buttonBeenden
            // 
            this.buttonBeenden.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.buttonBeenden, "buttonBeenden");
            this.buttonBeenden.Name = "buttonBeenden";
            this.buttonBeenden.UseVisualStyleBackColor = false;
            this.buttonBeenden.Click += new System.EventHandler(this.buttonBeenden_Click);
            // 
            // textBoxGegSprache
            // 
            resources.ApplyResources(this.textBoxGegSprache, "textBoxGegSprache");
            this.textBoxGegSprache.Name = "textBoxGegSprache";
            // 
            // buttonNeuWort
            // 
            this.buttonNeuWort.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.buttonNeuWort, "buttonNeuWort");
            this.buttonNeuWort.Name = "buttonNeuWort";
            this.buttonNeuWort.UseVisualStyleBackColor = false;
            this.buttonNeuWort.Click += new System.EventHandler(this.buttonNeuWort_Click);
            // 
            // labelGegSprache
            // 
            resources.ApplyResources(this.labelGegSprache, "labelGegSprache");
            this.labelGegSprache.BackColor = System.Drawing.Color.Transparent;
            this.labelGegSprache.Name = "labelGegSprache";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Name = "label3";
            // 
            // buttonFehlerliste
            // 
            this.buttonFehlerliste.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.buttonFehlerliste, "buttonFehlerliste");
            this.buttonFehlerliste.Name = "buttonFehlerliste";
            this.buttonFehlerliste.UseVisualStyleBackColor = false;
            this.buttonFehlerliste.Click += new System.EventHandler(this.buttonFehlerliste_Click);
            // 
            // Vokabelabfrage
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonFehlerliste);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelGegSprache);
            this.Controls.Add(this.buttonBeenden);
            this.Controls.Add(this.buttonNeuWort);
            this.Controls.Add(this.textBoxGegSprache);
            this.Controls.Add(this.buttonGerFrench);
            this.Controls.Add(this.labelGesSprache);
            this.Controls.Add(this.buttonEngFrench);
            this.Controls.Add(this.buttonCheck);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxAntwort);
            this.Controls.Add(this.buttonFrenchEng);
            this.Controls.Add(this.buttonFrenchGer);
            this.Controls.Add(this.labelPunkte);
            this.Name = "Vokabelabfrage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonFrenchGer;
        private System.Windows.Forms.TextBox textBoxAntwort;
        private System.Windows.Forms.Button buttonCheck;
        private System.Windows.Forms.Label labelGesSprache;
        private System.Windows.Forms.Button buttonGerFrench;
        private System.Windows.Forms.Button buttonFrenchEng;
        private System.Windows.Forms.Button buttonEngFrench;
        private System.Windows.Forms.Label labelPunkte;
        private System.Windows.Forms.Button buttonBeenden;
        private System.Windows.Forms.TextBox textBoxGegSprache;
        private System.Windows.Forms.Button buttonNeuWort;
        private System.Windows.Forms.Label labelGegSprache;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonFehlerliste;
    }
}